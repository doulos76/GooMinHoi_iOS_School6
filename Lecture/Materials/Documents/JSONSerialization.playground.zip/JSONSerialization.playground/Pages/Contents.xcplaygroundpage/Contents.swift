/*:
 # JSONSerialization
 
 1. **Creating JSON Data**
 2. **Creating a JSON Object**
 
 by Giftbot
*/
//: [Next](@next)
