import UIKit

final class CardCell: UICollectionViewCell {
  
  @IBOutlet weak var cardImageView: UIImageView!
  @IBOutlet weak var nameLabel: UILabel!
  
}
