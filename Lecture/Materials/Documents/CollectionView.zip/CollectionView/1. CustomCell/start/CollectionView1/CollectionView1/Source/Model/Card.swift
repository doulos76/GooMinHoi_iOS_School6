
struct Card: Codable {
  let name: String
  let image: String
}
