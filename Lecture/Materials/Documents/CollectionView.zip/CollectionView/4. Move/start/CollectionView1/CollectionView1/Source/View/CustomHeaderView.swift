import UIKit

final class CustomHeaderView: UICollectionReusableView {
  
  @IBOutlet weak var headerImageView: UIImageView!
  
  @IBOutlet weak var headerNameLabel: UILabel!
  
  
}
