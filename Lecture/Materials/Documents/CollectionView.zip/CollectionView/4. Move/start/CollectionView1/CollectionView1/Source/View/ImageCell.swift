import UIKit

final class ImageCell: UICollectionViewCell {
  
  @IBOutlet weak var nameLabel: UILabel!
  @IBOutlet weak var cardImage: UIImageView!
}
