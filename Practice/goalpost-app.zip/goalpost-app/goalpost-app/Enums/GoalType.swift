//
//  GoalType.swift
//  goalpost-app
//
//  Created by dave on 05/09/2018.
//  Copyright © 2018 dave. All rights reserved.
//

import Foundation

enum GoalType: String {
  case longTerm = "Long Term"
  case shortTerm = "Short Term"
}
