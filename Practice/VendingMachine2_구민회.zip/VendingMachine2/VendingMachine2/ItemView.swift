//
//  ItemView.swift
//  VendingMachine2
//
//  Created by 구민회 on 2018. 2. 7..
//  Copyright © 2018년 mobileandsmile. All rights reserved.
//

import UIKit


/// 자판기 판매 음료에 대한 화면 구성
class ItemView: UIView {
    
    /// 음료에 대한 view
    var itemView: UIView?
    /// 음료 imageView
    var itemImage: UIImageView?
    /// 음료 가격 레이블
    var itemPriceLabel: UILabel?
    /// 음료를 선택하기 위한 버튼
    var itemSelectButton: UIButton?
    
    
    var index: Int = 0
    var drinkItemList: [String] = ["콜라", "사이다", "칸타타", "삼다수"]
    var drinkItemPriceArray: [Int] = [1000, 800, 1500, 500]
//    var totalPurchasePrice: Int = 0
//    var vendingMachinsMoney: Int  = 100000

    
    //MARK: - initializer
    override init(frame: CGRect) {
        super.init(frame: frame)
        makeItemView(count: 4)
        updateArray()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    //MARK: - private methode
    
    ///  한 종류의 음료를 구성하는 View
    ///  서브뷰>이미지뷰,레이블
    /// - Parameter count: display  되는 음료의 종류
    func makeItemView(count: Int) {
        
        for index in 0..<count {
            itemView = UIView()
            itemView?.backgroundColor = UIColor.blue
            itemView?.alpha = 0.3
 //           itemView?.frame = CGRect(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height)
            self.addSubview(itemView!)
            
            itemImage = UIImageView()
            itemImage?.image = UIImage(named: drinkItemList[index])
            //itemImage?.frame = CGRect(x: 0, y: 0, width: self.frame.size.width * 2 / 3, height: self.frame.size.height * 2/3)
            self.addSubview(itemImage!)
            
            itemPriceLabel = UILabel()
            itemPriceLabel?.text = String(drinkItemPriceArray[index]) + "원"
            itemPriceLabel?.textAlignment = NSTextAlignment.right
            //itemPriceLabel?.frame = CGRect(x: 50, y: 50, width: self.frame.size.width * 2 / 3, height: self.frame.size.height * 2/3)
            self.addSubview(itemPriceLabel!)
            
            itemSelectButton = UIButton(type: .custom)
            //itemSelectButton?.frame = CGRect(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height)
            self.addSubview(itemSelectButton!)
            
        }
        
    }
    
    /// frame 구성
    func updateArray() {
        //  subView margin
        let margin: CGFloat = 20
        // 2x2 형태로 하기 위해 필요 (행)
        let column: CGFloat = CGFloat(index % 2)
        // 2x2 형태로 하기 위해 필요 (열)
        let row: CGFloat = CGFloat(index / 2)
        
        for index in 0..<4
        {
            // itemView frame  위치 설정
            itemView?.frame = CGRect(x: margin + column * self.frame.size.width / 2,
                                     y: margin + row * self.frame.size.height / 2,
                                     width: 150 + self.frame.size.width * column,
                                     height: 150 + self.frame.size.height * column)
            // itemImage frame  위치 설정
            itemImage?.frame = CGRect(x: margin + column * itemView!.frame.size.width / 2,
                                      y: margin + row * itemView!.frame.size.height / 2,
                                      width: 150,
                                      height: 150)
            // itemPriceLabel frame  위치 설정
            itemPriceLabel?.frame = CGRect(x: margin + column * itemView!.frame.size.width / 2,
                                      y: margin + row * itemView!.frame.size.height / 2,
                                      width: 150,
                                      height: 150)
            // itemSelectedButton frame  위치 설정
            itemSelectButton?.frame = CGRect(x: margin + column * itemView!.frame.size.width / 2,
                                           y: margin + row * itemView!.frame.size.height / 2,
                                           width: 150,
                                           height: 150)

        }
        self.addSubview(itemView!)
    }

}
